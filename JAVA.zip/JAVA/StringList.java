import java.util.ArrayList;
import java.util.Scanner;

public class StringList {

    public static void main(String[] args) {
        
        ArrayList<String> shortStrings = new ArrayList<String>();
        ArrayList<String> longStrings = new ArrayList<String>();
        Scanner scanner = new Scanner(System.in);

        for (int i = 1; i <= 20; i++) {
            System.out.print("Enter string #" + i + ": ");
            String str = scanner.nextLine();
            if (str.length() <= 5) {
                shortStrings.add(str);
            } else {
                longStrings.add(str);
            }
        }

        System.out.print("Enter 'short' or 'long' to display the corresponding list: ");
        String input = scanner.nextLine().toLowerCase();

        if (input.equals("short")) {
            if (shortStrings.size() > 0) {
                System.out.println("Short strings:");
                for (String str : shortStrings) {
                    System.out.println(str);
                }
            } else {
                System.out.println("No short strings were entered.");
            }
        } else if (input.equals("long")) {
            if (longStrings.size() > 0) {
                System.out.println("Long strings:");
                for (String str : longStrings) {
                    System.out.println(str);
                }
            } else {
                System.out.println("No long strings were entered.");
            }
        } else {
            System.out.println("Invalid input. Please enter 'short' or 'long'.");
        }
        scanner.close();
    }
}