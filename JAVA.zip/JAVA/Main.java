import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Create an array of eight integers
        int[] arr = {3, 7, 1, 9, 2, 8, 5, 4};

        // Display all the integers
        System.out.println("All integers: " + Arrays.toString(arr));

        // Display all the integers in reverse order
        int[] reversedArr = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            reversedArr[i] = arr[arr.length - i - 1];
        }
        System.out.println("Integers in reverse order: " + Arrays.toString(reversedArr));

        // Display the sum of the eight integers
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        System.out.println("Sum of integers: " + sum);

        // Display all values less than 5
        System.out.print("Values less than 5: ");
        for (int num : arr) {
            if (num < 5) {
                System.out.print(num + " ");
            }
        }
        System.out.println();

        // Display the lowest value
        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        System.out.println("Lowest value: " + min);

        // Display the highest value
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("Highest value: " + max);

        // Calculate and display the average
        double avg = (double) sum / arr.length;
        System.out.println("Average: " + avg);

        // Display all values that are higher than the calculated average value
        System.out.print("Values higher than average: ");
        for (int num : arr) {
            if (num > avg) {
                System.out.print(num + " ");
            }
        }
        System.out.println();
    }
}