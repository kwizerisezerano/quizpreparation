import java.util.Scanner;

public class FriendList {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] names = new String[20];
        int[] telephoneNumbers = new int[20];

        // input names and telephone numbers
        for (int i = 0; i < 20; i++) {
            System.out.print("Enter name of friend " + (i+1) + ": ");
            names[i] = input.nextLine();
            System.out.print("Enter telephone number of friend " + (i+1) + ": ");
            telephoneNumbers[i] = input.nextInt();
            input.nextLine(); // consume the newline character
        }

        // sort the names in alphabetical order using selection sort
        for (int i = 0; i < names.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < names.length; j++) {
                if (names[j].compareToIgnoreCase(names[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            String tempName = names[i];
            names[i] = names[minIndex];
            names[minIndex] = tempName;
            int tempNumber = telephoneNumbers[i];
            telephoneNumbers[i] = telephoneNumbers[minIndex];
            telephoneNumbers[minIndex] = tempNumber;
        }

        // display names that begin with vowels along with their telephone numbers
        System.out.println("Names beginning with vowels:");
        for (int i = 0; i < names.length; i++) {
            if (names[i].matches("(?i)[aeiou].*")) { // regex for names that start with vowels
                System.out.println(names[i] + ": " + telephoneNumbers[i]);
            }
        }
    }
}