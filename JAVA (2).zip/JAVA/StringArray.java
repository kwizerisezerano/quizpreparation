import java.util.Scanner;

public class StringArray {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Take input from user
        System.out.print("Enter first string: ");
        String str1 = input.nextLine();
        System.out.print("Enter second string: ");
        String str2 = input.nextLine();
        
        // Save strings in array
        String[] arr = { str1, str2 };
        
        // Count characters that appear in both strings
        int count = 0;
        String common = "";
        for (int i = 0; i < arr[0].length(); i++) {
            char c = arr[0].charAt(i);
            if (arr[1].indexOf(c) != -1 && common.indexOf(c) == -1) {
                count++;
                common += c;
            }
        }
        
        // Output result
        System.out.println("Number of characters in first string that also appear in second string: " + count);
        System.out.println("Common characters: " + common);
    }
}