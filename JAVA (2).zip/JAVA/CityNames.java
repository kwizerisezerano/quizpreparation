import java.util.Scanner;

public class CityNames {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] cities = new String[10];
        char[] vowels = {'a', 'e', 'i', 'o', 'u'};

        // Input the names of the cities
        System.out.println("Enter the names of 10 cities:");
        for (int i = 0; i < cities.length; i++) {
            cities[i] = input.nextLine().toLowerCase();
        }

        // Display the names of cities that begin with a consonant and end with a vowel
        System.out.println("Cities that begin with a consonant and end with a vowel:");
        for (String city : cities) {
            if (!isVowel(city.charAt(0)) && isVowel(city.charAt(city.length()-1))) {
                System.out.println(city);
            }
        }
    }

    // Helper method to check if a character is a vowel
    public static boolean isVowel(char c) {
        char ch = Character.toLowerCase(c);
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }
}
