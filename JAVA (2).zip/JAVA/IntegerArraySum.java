import java.util.Arrays;
import java.util.Scanner;

public class IntegerArraySum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a series of integers separated by spaces: ");
        String input = scanner.nextLine();
        String[] stringArray = input.split(" ");
        int[] intArray = new int[stringArray.length];
        int sum = 0;
        for (int i = 0; i < stringArray.length; i++) {
            intArray[i] = Integer.parseInt(stringArray[i]);
            sum += intArray[i];
        }
        System.out.println("List of integers: " + Arrays.toString(intArray));
        System.out.println("Sum of integers: " + sum);
    }
}